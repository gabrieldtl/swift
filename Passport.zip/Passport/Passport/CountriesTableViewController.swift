//
//  CountriesTableViewController.swift
//  Passport
//
//  Created by Students on 29/5/19.
//  Copyright © 2019 VU. All rights reserved.
//

import UIKit

class CountriesTableViewController: UITableViewController {
    var countries = ["Italy","Japan","Portugal"]
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"reuseIdentifier", for: indexPath)
        let country = countries[indexPath.row]
        cell.textLabel?.text = country
        return cell
        
    }    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        //Return the number of sections.
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of sections.
        return 3
    }
    


}
