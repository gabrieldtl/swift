//
//  WeightVC.swift
//  Assign6
//
//  Created by John Denison on 8/06/2019.
//  Copyright © 2019 Banana Republic Software. All rights reserved.
//

import UIKit

class WeightVC: UIViewController {

    @IBOutlet weak var WeightInput: UITextField!
    
    @IBOutlet weak var WeightResult: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func LbsToKgs(_ sender: Any) {
        var a: Double? = Double(WeightInput.text!)
        a = a! * 0.453592
        WeightResult.text = String(format:"%.3f", a!)
    }

    @IBAction func KgsToLbs(_ sender: Any) {
        var a: Double? = Double(WeightInput.text!)
        a = a! * 2.20462
        WeightResult.text = String(format:"%.3f", a!)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
